<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recopilar y filtrar los datos del formulario
    $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_STRING);
    $direccion = filter_input(INPUT_POST, 'direccion', FILTER_SANITIZE_STRING);
    $telefono = filter_input(INPUT_POST, 'telefono', FILTER_SANITIZE_STRING);
    $correo = filter_input(INPUT_POST, 'correo', FILTER_SANITIZE_EMAIL);
    $fecha_visita = filter_input(INPUT_POST, 'fecha_visita', FILTER_SANITIZE_STRING);
    $comentario = filter_input(INPUT_POST, 'comentario', FILTER_SANITIZE_STRING);

    // Validar los datos aquí según tus requerimientos (por ejemplo, longitud máxima, formato de correo, etc.).

    // Conexión a la base de datos
    $db = new mysqli("localhost", "root", "", "cristian");

    if ($db->connect_error) {
        die("Error en la conexión a la base de datos: " . $db->connect_error);
    }

    // Preparar la consulta SQL para insertar los datos en la base de datos
    $sql = "INSERT INTO libro_visitas (nombre, direccion, telefono, correo, fecha_visita, comentario) VALUES (?, ?, ?, ?, ?, ?)";

    // Preparar la declaración
    $stmt = $db->prepare($sql);

    // Vincular parámetros
    $stmt->bind_param("ssssss", $nombre, $direccion, $telefono, $correo, $fecha_visita, $comentario);

    // Ejecutar la consulta
    if ($stmt->execute()) {
        // Redirigir al libro de visitas
        header("Location: libro_visitas.php");
    } else {
        echo "Error al guardar el mensaje en la base de datos.";
    }

    // Cerrar la declaración y la conexión
    $stmt->close();
    $db->close();
} else {
    // Si se intenta acceder directamente a este archivo, redirigir al libro de visitas
    header("Location: libro_visitas.php");
}
?>
