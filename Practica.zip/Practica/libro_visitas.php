<!DOCTYPE html>
<html>
<head>
    <title>Libro de Visitas Chamuco S.A</title>
    <style>
        body {
            background: linear-gradient(to bottom, #FF0000, #AA0000); /* Fondo degradado de rojo a un tono más oscuro de rojo */
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8); /* Fondo semitransparente */
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        form {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f0f0f0;
        }
        .info-container {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Chamuco S.A - Libro de Visitas</h1>
        <p>Por favor, deje su comentario:</p>
        <form method="post" action="procesar_mensaje.php">
            Nombre: <input type="text" name="nombre" required><br>
            Dirección: <input type="text" name="direccion"><br>
            Teléfono: <input type="text" name="telefono"><br>
            Correo Electrónico: <input type="email" name="correo"><br>
            Fecha de Visita: <input type="date" name="fecha_visita"><br>
            Comentario: <textarea name="comentario" required></textarea><br>
            <input type="submit" value="Enviar">
        </form>

        <div class="info-container">
            <h2>Mensajes Anteriores:</h2>
            <table>
                <tr>
                    <th>Nombre</th>
                    <th>Dirección</th>
                    <th>Teléfono</th>
                    <th>Correo Electrónico</th>
                    <th>Fecha de Visita</th>
                    <th>Comentario</th>
                </tr>
                <?php
                // Conectarse a la base de datos (reemplaza con tus propios valores)
                $host = 'localhost';
                $usuario = 'root';
                $contrasena = '';
                $base_de_datos = 'cristian';

                $conexion = new mysqli($host, $usuario, $contrasena, $base_de_datos);

                if ($conexion->connect_error) {
                    die("Error en la conexión a la base de datos: " . $conexion->connect_error);
                }

                // Consulta para recuperar mensajes anteriores
                $sql = "SELECT nombre, direccion, telefono, correo, fecha_visita, comentario FROM libro_visitas";
                $resultado = $conexion->query($sql);

                if ($resultado->num_rows > 0) {
                    while ($fila = $resultado->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $fila["nombre"] . "</td>";
                        echo "<td>" . $fila["direccion"] . "</td>";
                        echo "<td>" . $fila["telefono"] . "</td>";
                        echo "<td>" . $fila["correo"] . "</td>";
                        echo "<td>" . $fila["fecha_visita"] . "</td>";
                        echo "<td>" . $fila["comentario"] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No hay mensajes anteriores.</td></tr>";
                }

                // Cerrar la conexión a la base de datos
                $conexion->close();
                ?>
            </table>
        </div>
    </div>
</body>
</html>
